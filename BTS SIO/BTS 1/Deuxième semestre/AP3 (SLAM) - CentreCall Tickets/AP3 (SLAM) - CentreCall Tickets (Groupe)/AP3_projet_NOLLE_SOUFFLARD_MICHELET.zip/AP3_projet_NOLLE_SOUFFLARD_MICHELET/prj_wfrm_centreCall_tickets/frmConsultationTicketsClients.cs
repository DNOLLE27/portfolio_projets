﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmConsultationTicketsClients : Form
    {
        public frmConsultationTicketsClients()
        {
            InitializeComponent();
        }

        private void frmConsultationTicketsClients_Load(object sender, EventArgs e)
        {
            for (int j = 0; j < tab.nbClients; j++)
            {
                cb_ticket_client.Items.Add(tab.client[j].raisonSociale);
            }
        }

        private void cb_ticket_client_SelectedIndexChanged(object sender, EventArgs e)
        {
            int clientNum = cb_ticket_client.SelectedIndex + 1;

            lv_consultation_ticket_client.Items.Clear();

            if (tab.nbTickets == 0)
            {
                MessageBox.Show("Aucun ticket", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for (int i = 0; i < tab.nbTickets; i++)
                {
                    if (tab.ticket[i].numClient == clientNum)
                    {
                        ListViewItem ligne = new ListViewItem();
                        ligne.Text = tab.ticket[i].numero.ToString();
                        ligne.SubItems.Add(tab.ticket[i].dateOuverture.ToShortDateString());
                        int iClient = tab.ticket[i].numClient - 1;
                        ligne.SubItems.Add(tab.ticket[i].objet);

                        if (tab.ticket[i].cloture)
                            ligne.SubItems.Add("OUI");
                        else
                            ligne.SubItems.Add("NON");

                        if (tab.ticket[i].cloture) ligne.SubItems.Add(tab.ticket[i].dateCloture.ToShortDateString());
                        if (tab.ticket[i].cloture)
                        {
                            ligne.SubItems.Add(String.Format("{0:N2}", tab.ticket[i].nbHeures));
                        }
                        if (tab.ticket[i].cloture)
                        {
                            int iTech = tab.ticket[i].numTech - 1;
                            ligne.SubItems.Add(tab.tech[iTech].nom + " " + tab.tech[iTech].prenom);
                        }
                        lv_consultation_ticket_client.Items.Add(ligne);
                    }
                }
            }
        }
    }
}
