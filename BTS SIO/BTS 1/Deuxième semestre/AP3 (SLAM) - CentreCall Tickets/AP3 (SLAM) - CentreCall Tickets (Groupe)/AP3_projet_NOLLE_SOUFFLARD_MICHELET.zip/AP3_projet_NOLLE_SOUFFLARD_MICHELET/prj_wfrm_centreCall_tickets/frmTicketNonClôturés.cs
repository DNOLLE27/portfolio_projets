﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmTicketNonClôturés : Form
    {
        public frmTicketNonClôturés()
        {
            InitializeComponent();
        }

        private void frmTicketNonClôturés_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < tab.nbTickets; i++)
            {
                if (tab.ticket[i].cloture == false)
                {
                    ListViewItem ligne = new ListViewItem();
                    ligne.Text = tab.ticket[i].numero.ToString();
                    ligne.SubItems.Add(tab.ticket[i].dateOuverture.ToShortDateString());
                    int iClient = tab.ticket[i].numClient - 1;
                    ligne.SubItems.Add(tab.client[iClient].raisonSociale);
                    ligne.SubItems.Add(tab.ticket[i].objet);
                    int iTech = tab.ticket[i].numTech - 1;
                    if (iTech > tab.nbTech)
                    {
                        ligne.SubItems.Add("");

                    }
                    else
                    {
                        ligne.SubItems.Add(tab.tech[iTech].nom);
                        ligne.SubItems.Add(tab.tech[iTech].prenom);
                    }

                    lVTicketNonClotures.Items.Add(ligne);


                }
            }
        }
    }
}
