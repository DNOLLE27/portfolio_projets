﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmConsulterNbTicketsStats : Form
    {
        public frmConsulterNbTicketsStats()
        {
            InitializeComponent();
        }

        private void frmConsulterNbTicketsStats_Load(object sender, EventArgs e)
        {
            int nbTicketsclients = 0;
            if (tab.nbTickets == 0)
            {
                MessageBox.Show("Aucun fichier ouvert", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for (int i = 0; i < tab.nbClients; i++)
                {
                    ListViewItem ligne = new ListViewItem();
                    ligne.Text = tab.client[i].raisonSociale.ToString();
                    for (int k = 0; k < tab.nbTickets; k++)
                    {
                        if (tab.client[i].numero == tab.ticket[k].numClient)
                        {
                            nbTicketsclients = nbTicketsclients + 1;
                            ligne.SubItems.Add(nbTicketsclients.ToString());
                        }
                    }
                    lv_consulter_nb_ticket_client.Items.Add(ligne);
                    nbTicketsclients = 0;
                }
            }
        }
    }
}
