﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmDureeMiniContrat : Form
    {
        public frmDureeMiniContrat()
        {
            InitializeComponent();
        }

        private void frmDureeMiniContrat_Load(object sender, EventArgs e)
        {
            // Initialisation de toutes les TextBox pour être en lecture seulemment
            tbCAClientMini.Enabled = false;
            tbDateContratMini.Enabled = false;
            tbDureeMini.Enabled = false;
            tbMtContratMini.Enabled = false;
            tbMtTicketsMini.Enabled = false;
            tbNAFClientMini.Enabled = false;
            tbNumClientMini.Enabled = false;
            tbRSClientMini.Enabled = false;
        }

        private void btnRechercherMini_Click(object sender, EventArgs e)
        {
            // Effacage automatiques des TextBox à chaque appui sur le bouton "Rechercher" pour éviter que ça écrive par dessus ce qu'il y a déjà d'affiché
            tbCAClientMini.Text = tbDateContratMini.Text = tbDureeMini.Text = tbMtContratMini.Text = tbMtTicketsMini.Text = tbNAFClientMini.Text = tbNumClientMini.Text = tbRSClientMini.Text = "";

            // Initialisation des variables pour la recherche du contrat avec la plus petite durée
            int indexClientMini = 0;
            int rechDureeMini = 0;
            bool minitrouve = false;

            // Recherche du contrat avec la plus petite durée
            while (rechDureeMini < tab.nbClients && minitrouve == false)
            {
                rechDureeMini = rechDureeMini + 1;

                for (int i = 0; i < tab.nbClients; i++)
                {
                    if (rechDureeMini == tab.client[i].duree)
                    {
                        minitrouve = true;
                        indexClientMini = indexClientMini + i;
                    }
                }
            }

            // Affichage de toutes les données du client avec la plus petite durée de contrat
            // Affichage du numéro de contrat
            tbNumClientMini.Text = tab.client[indexClientMini].numero.ToString();
            
            // Affichage de la raison sociale
            tbRSClientMini.Text = tab.client[indexClientMini].raisonSociale;

            // Affichage de la ville du centre d'appel
            int iCentre = tab.client[indexClientMini].centreAppel - 1;
            tbCAClientMini.Text = tab.centreAppel[iCentre].ville;

            // Affichage du code NAF
            int iNaf = tab.client[indexClientMini].codeNaf - 1;
            int lgIntitule = tab.codeNaf[iNaf].intitule.Length;
            if (lgIntitule > 50) lgIntitule = 50;
            tbNAFClientMini.Text = tab.codeNaf[iNaf].intitule.Substring(0, lgIntitule);

            // Affichage de la date du contrat
            tbDateContratMini.Text = tab.client[indexClientMini].dateContrat.ToShortDateString();
            
            // Affichage de la durée du contrat
            tbDureeMini.Text = Convert.ToString(rechDureeMini);
            
            // Affichage du montant du contrat
            tbMtContratMini.Text = String.Format("{0:C}", tab.client[indexClientMini].montantContrat);
            
            // Affichage du montant total des tickets
            tbMtTicketsMini.Text = String.Format("{0:C}", tab.client[indexClientMini].montantTickets);
        }
    }
}
