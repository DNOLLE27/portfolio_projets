﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRechercher = new System.Windows.Forms.Button();
            this.lvCodeNaf = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.cbClientNaf = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnRechercher
            // 
            this.btnRechercher.Location = new System.Drawing.Point(428, 120);
            this.btnRechercher.Margin = new System.Windows.Forms.Padding(2);
            this.btnRechercher.Name = "btnRechercher";
            this.btnRechercher.Size = new System.Drawing.Size(76, 19);
            this.btnRechercher.TabIndex = 7;
            this.btnRechercher.Text = "Rechercher";
            this.btnRechercher.UseVisualStyleBackColor = true;
            this.btnRechercher.Click += new System.EventHandler(this.btnRechercher_Click);
            // 
            // lvCodeNaf
            // 
            this.lvCodeNaf.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvCodeNaf.HideSelection = false;
            this.lvCodeNaf.Location = new System.Drawing.Point(38, 34);
            this.lvCodeNaf.Margin = new System.Windows.Forms.Padding(2);
            this.lvCodeNaf.Name = "lvCodeNaf";
            this.lvCodeNaf.Size = new System.Drawing.Size(302, 253);
            this.lvCodeNaf.TabIndex = 6;
            this.lvCodeNaf.UseCompatibleStateImageBehavior = false;
            this.lvCodeNaf.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "N° client";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Raison Sociale";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(401, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Code NAF des activités répertoriées";
            // 
            // cbClientNaf
            // 
            this.cbClientNaf.FormattingEnabled = true;
            this.cbClientNaf.Location = new System.Drawing.Point(384, 72);
            this.cbClientNaf.Margin = new System.Windows.Forms.Padding(2);
            this.cbClientNaf.Name = "cbClientNaf";
            this.cbClientNaf.Size = new System.Drawing.Size(186, 21);
            this.cbClientNaf.TabIndex = 4;
            // 
            // frmClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 351);
            this.Controls.Add(this.btnRechercher);
            this.Controls.Add(this.lvCodeNaf);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbClientNaf);
            this.Name = "frmClient";
            this.Text = "frmClient";
            this.Load += new System.EventHandler(this.frmClient_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRechercher;
        private System.Windows.Forms.ListView lvCodeNaf;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbClientNaf;
    }
}