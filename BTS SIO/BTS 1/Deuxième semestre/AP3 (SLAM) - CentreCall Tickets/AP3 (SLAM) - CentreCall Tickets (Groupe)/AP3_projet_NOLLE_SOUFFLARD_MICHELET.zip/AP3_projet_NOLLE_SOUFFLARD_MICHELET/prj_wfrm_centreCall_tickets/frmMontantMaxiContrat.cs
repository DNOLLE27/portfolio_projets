﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmMontantMaxiContrat : Form
    {
        public frmMontantMaxiContrat()
        {
            InitializeComponent();
        }

        private void frmMontantMaxiContrat_Load(object sender, EventArgs e)
        {
            Single mtVerif1 = tab.client[0].montantContrat;
            Single mtVerif2 = tab.client[1].montantContrat;
            Single mtMax;
            int index;
            if (mtVerif1 > mtVerif2)
            {
                mtMax = mtVerif1;
                index = 0;
            }
            else if (mtVerif1 < mtVerif2)
            {
                mtMax = mtVerif2;
                index = 1;
            }
            else
            {
                mtMax = mtVerif1;
                index = 0;
            }
            for (int i = 2; i < tab.nbClients; i++)
            {
                if (tab.client[i].montantContrat > mtMax)
                {
                    mtMax = tab.client[i].montantContrat;
                    index = i;
                }
            }
            ListViewItem ligne = new ListViewItem();
            ligne.Text = tab.client[index].numero.ToString();
            ligne.SubItems.Add(tab.client[index].raisonSociale);
            int iCentre = tab.client[index].centreAppel - 1;
            ligne.SubItems.Add(tab.centreAppel[iCentre].ville);
            int iNaf = tab.client[index].codeNaf - 1;
            ligne.SubItems.Add(tab.codeNaf[iNaf].intitule);
            ligne.SubItems.Add(tab.client[index].dateContrat.ToShortDateString());
            ligne.SubItems.Add(tab.client[index].duree.ToString());
            ligne.SubItems.Add(String.Format("{0:C}", tab.client[index].montantContrat));
            ligne.SubItems.Add(String.Format("{0:C}", tab.client[index].montantTickets));
            lVMontantContrat.Items.Add(ligne);
        }
    }
}
