﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmConsulterNbTicketsStats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lv_consulter_nb_ticket_client = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lv_consulter_nb_ticket_client
            // 
            this.lv_consulter_nb_ticket_client.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lv_consulter_nb_ticket_client.HideSelection = false;
            this.lv_consulter_nb_ticket_client.Location = new System.Drawing.Point(11, 11);
            this.lv_consulter_nb_ticket_client.Margin = new System.Windows.Forms.Padding(2);
            this.lv_consulter_nb_ticket_client.Name = "lv_consulter_nb_ticket_client";
            this.lv_consulter_nb_ticket_client.Size = new System.Drawing.Size(762, 462);
            this.lv_consulter_nb_ticket_client.TabIndex = 1;
            this.lv_consulter_nb_ticket_client.UseCompatibleStateImageBehavior = false;
            this.lv_consulter_nb_ticket_client.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Raison Sociale";
            this.columnHeader1.Width = 307;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nombre de tickets";
            this.columnHeader2.Width = 265;
            // 
            // frmConsulterNbTicketsStats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 493);
            this.Controls.Add(this.lv_consulter_nb_ticket_client);
            this.Name = "frmConsulterNbTicketsStats";
            this.Text = "frmConsulterNbTicketsStats";
            this.Load += new System.EventHandler(this.frmConsulterNbTicketsStats_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lv_consulter_nb_ticket_client;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}