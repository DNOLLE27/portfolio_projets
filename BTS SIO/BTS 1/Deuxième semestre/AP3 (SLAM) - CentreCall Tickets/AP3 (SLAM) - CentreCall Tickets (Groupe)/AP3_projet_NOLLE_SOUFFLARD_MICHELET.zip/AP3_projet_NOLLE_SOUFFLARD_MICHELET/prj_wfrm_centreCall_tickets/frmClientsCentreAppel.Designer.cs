﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmClientsCentreAppel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvClientsCentreAppel = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cbCentreAppel = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRecherche = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvClientsCentreAppel
            // 
            this.lvClientsCentreAppel.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvClientsCentreAppel.FullRowSelect = true;
            this.lvClientsCentreAppel.HideSelection = false;
            this.lvClientsCentreAppel.Location = new System.Drawing.Point(13, 13);
            this.lvClientsCentreAppel.Name = "lvClientsCentreAppel";
            this.lvClientsCentreAppel.Size = new System.Drawing.Size(395, 360);
            this.lvClientsCentreAppel.TabIndex = 0;
            this.lvClientsCentreAppel.UseCompatibleStateImageBehavior = false;
            this.lvClientsCentreAppel.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "N°";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Raison sociale";
            this.columnHeader2.Width = 190;
            // 
            // cbCentreAppel
            // 
            this.cbCentreAppel.FormattingEnabled = true;
            this.cbCentreAppel.Location = new System.Drawing.Point(38, 40);
            this.cbCentreAppel.Name = "cbCentreAppel";
            this.cbCentreAppel.Size = new System.Drawing.Size(121, 21);
            this.cbCentreAppel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Centre d\'appel (villes) :";
            // 
            // btnRecherche
            // 
            this.btnRecherche.Location = new System.Drawing.Point(62, 67);
            this.btnRecherche.Name = "btnRecherche";
            this.btnRecherche.Size = new System.Drawing.Size(75, 23);
            this.btnRecherche.TabIndex = 3;
            this.btnRecherche.Text = "Rechercher";
            this.btnRecherche.UseVisualStyleBackColor = true;
            this.btnRecherche.Click += new System.EventHandler(this.btnRecherche_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnRecherche);
            this.groupBox1.Controls.Add(this.cbCentreAppel);
            this.groupBox1.Location = new System.Drawing.Point(414, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rechercher clients par centre d\'appel";
            // 
            // frmClientsCentreAppel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 394);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lvClientsCentreAppel);
            this.Name = "frmClientsCentreAppel";
            this.Text = "Clients - Clients par centre d\'appel";
            this.Load += new System.EventHandler(this.frmClientsCentreAppel_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvClientsCentreAppel;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ComboBox cbCentreAppel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRecherche;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}