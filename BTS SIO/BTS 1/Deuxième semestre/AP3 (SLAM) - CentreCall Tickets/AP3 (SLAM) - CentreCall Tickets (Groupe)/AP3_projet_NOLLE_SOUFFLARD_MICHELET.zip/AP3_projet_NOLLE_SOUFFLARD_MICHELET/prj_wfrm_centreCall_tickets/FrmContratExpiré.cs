﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class FrmContratExpiré : Form
    {
        public FrmContratExpiré()
        {
            InitializeComponent();
        }

        private void FrmContratExpiré_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < tab.nbClients; i++)
            {
                DateTime DateFin = tab.client[i].dateContrat.AddMonths(tab.client[i].duree);
                if (DateTime.Now > DateFin)
                {
                    ListViewItem ligne = new ListViewItem();
                    ligne.Text = tab.client[i].numero.ToString();
                    ligne.SubItems.Add(tab.client[i].raisonSociale);
                    ligne.SubItems.Add(tab.client[i].dateContrat.ToShortDateString());
                    ligne.SubItems.Add(tab.client[i].duree.ToString());
                    ligne.SubItems.Add(String.Format("{0:C}", tab.client[i].montantContrat));
                    ligne.SubItems.Add(String.Format("{0:C}", tab.client[i].montantTickets));
                    lVContratExpire.Items.Add(ligne);
                }
            }
        }
    }
}
