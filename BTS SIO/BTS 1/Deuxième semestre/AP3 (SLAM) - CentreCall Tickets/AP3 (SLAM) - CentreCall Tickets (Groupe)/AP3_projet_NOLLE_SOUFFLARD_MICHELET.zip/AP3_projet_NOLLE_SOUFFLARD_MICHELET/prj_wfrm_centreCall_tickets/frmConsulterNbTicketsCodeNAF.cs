﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmConsulterNbTicketsCodeNAF : Form
    {
        public frmConsulterNbTicketsCodeNAF()
        {
            InitializeComponent();
        }

        private void frmConsulterNbTicketsCodeNAF_Load(object sender, EventArgs e)
        {
            int nbTicketscodenaf = 0;
            if (tab.nbTickets == 0)
            {
                MessageBox.Show("Aucun fichier ouvert", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for (int i = 0; i < tab.nbCodesNaf; i++)
                {
                    nbTicketscodenaf = 0;
                    ListViewItem ligne = new ListViewItem();
                    ligne.Text = tab.codeNaf[i].code.ToString();
                    ligne.SubItems.Add(tab.codeNaf[i].intitule.ToString());
                    for (int k = 0; k < tab.nbClients; k++)
                    {
                        if (tab.client[k].codeNaf == tab.codeNaf[i].code)
                        {
                            nbTicketscodenaf = nbTicketscodenaf + 1;
                        }

                    }
                    ligne.SubItems.Add(nbTicketscodenaf.ToString());
                    lv_consulter_tickets_code_naf.Items.Add(ligne);

                }
            }
        }
    }
}
