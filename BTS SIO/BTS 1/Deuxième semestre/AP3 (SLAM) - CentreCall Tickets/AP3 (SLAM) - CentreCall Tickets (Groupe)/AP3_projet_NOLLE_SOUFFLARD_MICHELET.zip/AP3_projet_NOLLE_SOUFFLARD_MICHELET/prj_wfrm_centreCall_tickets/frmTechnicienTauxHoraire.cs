﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmTechnicienTauxHoraire : Form
    {
        public frmTechnicienTauxHoraire()
        {
            InitializeComponent();
        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            try
            {
                Single TauxHoraireMin = Convert.ToSingle(tbTauxMin.Text);
                Single TauxHoraireMax = Convert.ToSingle(tbTauxMax.Text);
                lVTechnicien.Items.Clear();
                if (TauxHoraireMin < TauxHoraireMax)
                {
                    for (int i = 0; i < tab.nbTech; i++)
                    {
                        if (tab.tech[i].tauxHoraire > TauxHoraireMin && tab.tech[i].tauxHoraire < TauxHoraireMax)
                        {
                            ListViewItem ligne = new ListViewItem();
                            ligne.Text = tab.tech[i].numero.ToString();
                            ligne.SubItems.Add(tab.tech[i].nom);
                            ligne.SubItems.Add(tab.tech[i].prenom);

                            lVTechnicien.Items.Add(ligne);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Vous ne pouvez pas avoir un taux horaire minimum supérieur au taux horaire maximum");
                }
            }
            catch
            {
                MessageBox.Show("Entrez des valeurs réelle");
            }
        }
    }
}
