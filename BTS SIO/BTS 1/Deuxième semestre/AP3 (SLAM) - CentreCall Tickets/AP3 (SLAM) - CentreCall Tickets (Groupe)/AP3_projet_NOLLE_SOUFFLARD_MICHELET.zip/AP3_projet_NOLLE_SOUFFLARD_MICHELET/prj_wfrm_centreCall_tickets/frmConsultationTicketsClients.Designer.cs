﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmConsultationTicketsClients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lv_consultation_ticket_client = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.cb_ticket_client = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lv_consultation_ticket_client
            // 
            this.lv_consultation_ticket_client.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.lv_consultation_ticket_client.HideSelection = false;
            this.lv_consultation_ticket_client.Location = new System.Drawing.Point(23, 97);
            this.lv_consultation_ticket_client.Margin = new System.Windows.Forms.Padding(2);
            this.lv_consultation_ticket_client.Name = "lv_consultation_ticket_client";
            this.lv_consultation_ticket_client.Size = new System.Drawing.Size(834, 444);
            this.lv_consultation_ticket_client.TabIndex = 5;
            this.lv_consultation_ticket_client.UseCompatibleStateImageBehavior = false;
            this.lv_consultation_ticket_client.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "N°";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Date";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Objet";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Clôture ?";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Date Clôture";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "NbHeure";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Techniciens";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(192, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(493, 31);
            this.label1.TabIndex = 4;
            this.label1.Text = "CONSULATATION TICKETS CLIENTS";
            // 
            // cb_ticket_client
            // 
            this.cb_ticket_client.FormattingEnabled = true;
            this.cb_ticket_client.Location = new System.Drawing.Point(352, 65);
            this.cb_ticket_client.Margin = new System.Windows.Forms.Padding(2);
            this.cb_ticket_client.Name = "cb_ticket_client";
            this.cb_ticket_client.Size = new System.Drawing.Size(146, 21);
            this.cb_ticket_client.TabIndex = 3;
            this.cb_ticket_client.SelectedIndexChanged += new System.EventHandler(this.cb_ticket_client_SelectedIndexChanged);
            // 
            // frmConsultationTicketsClients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 554);
            this.Controls.Add(this.lv_consultation_ticket_client);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_ticket_client);
            this.Name = "frmConsultationTicketsClients";
            this.Text = "frmConsultationTicketsClients";
            this.Load += new System.EventHandler(this.frmConsultationTicketsClients_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lv_consultation_ticket_client;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_ticket_client;
    }
}