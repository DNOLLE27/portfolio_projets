﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmClient : Form
    {
        public frmClient()
        {
            InitializeComponent();
        }

        private void frmClient_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < tab.nbCodesNaf; i++)
            {
                cbClientNaf.Items.Add(tab.codeNaf[i].intitule);
            }
        }

        private void btnRechercher_Click(object sender, EventArgs e)
        {
            string codeNAFsel = cbClientNaf.SelectedItem.ToString();
            int indexNAF = 0;

            for (int j = 0; j < tab.nbCodesNaf; j++)
            {
                if (tab.codeNaf[j].intitule == codeNAFsel)
                {
                    indexNAF = indexNAF + tab.codeNaf[j].code;
                }
            }



            for (int k = 0; k < tab.nbClients; k++)
            {
                if (tab.client[k].codeNaf == indexNAF)
                {
                    ListViewItem ligne = new ListViewItem();

                    ligne.Text = tab.client[k].numero.ToString();
                    ligne.SubItems.Add(tab.client[k].raisonSociale);

                    lvCodeNaf.Items.Add(ligne);
                }
            }
        }
    }
}
