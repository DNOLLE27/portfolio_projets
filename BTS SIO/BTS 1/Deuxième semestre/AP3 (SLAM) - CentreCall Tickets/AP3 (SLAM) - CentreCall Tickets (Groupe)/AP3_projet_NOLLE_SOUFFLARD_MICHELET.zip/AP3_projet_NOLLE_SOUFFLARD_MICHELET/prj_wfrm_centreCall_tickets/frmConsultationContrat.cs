﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmConsultationContrat : Form
    {
        public frmConsultationContrat()
        {
            InitializeComponent();
        }

        private void frmConsultationContrat_Load(object sender, EventArgs e)
        {
            float somme = 0;

            if (tab.nbClients == 0)
            {
                MessageBox.Show("Aucun Contrat", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for (int i = 0; i < tab.nbClients; i++)
                {
                    if (tab.client[i].montantTickets > tab.client[i].montantContrat)
                    {
                        ListViewItem ligne = new ListViewItem();
                        ligne.Text = tab.client[i].numero.ToString(); ;
                        ligne.SubItems.Add(tab.client[i].raisonSociale.ToString());
                        ligne.SubItems.Add(tab.client[i].montantContrat.ToString());
                        ligne.SubItems.Add(tab.client[i].montantTickets.ToString());

                        somme = somme + tab.client[i].montantContrat;
                        somme = somme - tab.client[i].montantTickets;
                        ligne.SubItems.Add(somme.ToString());
                        lv_contrat_consultation.Items.Add(ligne);
                    }
                }
            }
        }
    }
}
