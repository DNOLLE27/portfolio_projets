﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmDureeMiniContrat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbNumClientMini = new System.Windows.Forms.TextBox();
            this.tbRSClientMini = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNAFClientMini = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbCAClientMini = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbMtTicketsMini = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbMtContratMini = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbDureeMini = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbDateContratMini = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnRechercherMini = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numéro du client :";
            // 
            // tbNumClientMini
            // 
            this.tbNumClientMini.Location = new System.Drawing.Point(217, 33);
            this.tbNumClientMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbNumClientMini.Name = "tbNumClientMini";
            this.tbNumClientMini.Size = new System.Drawing.Size(185, 22);
            this.tbNumClientMini.TabIndex = 1;
            // 
            // tbRSClientMini
            // 
            this.tbRSClientMini.Location = new System.Drawing.Point(217, 65);
            this.tbRSClientMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbRSClientMini.Name = "tbRSClientMini";
            this.tbRSClientMini.Size = new System.Drawing.Size(185, 22);
            this.tbRSClientMini.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 69);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Raison sociale du client :";
            // 
            // tbNAFClientMini
            // 
            this.tbNAFClientMini.Location = new System.Drawing.Point(217, 127);
            this.tbNAFClientMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbNAFClientMini.Name = "tbNAFClientMini";
            this.tbNAFClientMini.Size = new System.Drawing.Size(185, 22);
            this.tbNAFClientMini.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(107, 130);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "NAF du client :";
            // 
            // tbCAClientMini
            // 
            this.tbCAClientMini.Location = new System.Drawing.Point(217, 95);
            this.tbCAClientMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbCAClientMini.Name = "tbCAClientMini";
            this.tbCAClientMini.Size = new System.Drawing.Size(185, 22);
            this.tbCAClientMini.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 98);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Centre d\'appel du client :";
            // 
            // tbMtTicketsMini
            // 
            this.tbMtTicketsMini.Location = new System.Drawing.Point(217, 249);
            this.tbMtTicketsMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbMtTicketsMini.Name = "tbMtTicketsMini";
            this.tbMtTicketsMini.Size = new System.Drawing.Size(185, 22);
            this.tbMtTicketsMini.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 252);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(195, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "Montant des tickets du client :";
            // 
            // tbMtContratMini
            // 
            this.tbMtContratMini.Location = new System.Drawing.Point(217, 217);
            this.tbMtContratMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbMtContratMini.Name = "tbMtContratMini";
            this.tbMtContratMini.Size = new System.Drawing.Size(185, 22);
            this.tbMtContratMini.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(72, 220);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Montant du contrat :";
            // 
            // tbDureeMini
            // 
            this.tbDureeMini.Location = new System.Drawing.Point(217, 187);
            this.tbDureeMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbDureeMini.Name = "tbDureeMini";
            this.tbDureeMini.Size = new System.Drawing.Size(185, 22);
            this.tbDureeMini.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(93, 191);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Duree (en mois) :";
            // 
            // tbDateContratMini
            // 
            this.tbDateContratMini.Location = new System.Drawing.Point(217, 155);
            this.tbDateContratMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbDateContratMini.Name = "tbDateContratMini";
            this.tbDateContratMini.Size = new System.Drawing.Size(185, 22);
            this.tbDateContratMini.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 159);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(171, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Date du contrat du client :";
            // 
            // btnRechercherMini
            // 
            this.btnRechercherMini.Location = new System.Drawing.Point(140, 293);
            this.btnRechercherMini.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRechercherMini.Name = "btnRechercherMini";
            this.btnRechercherMini.Size = new System.Drawing.Size(140, 50);
            this.btnRechercherMini.TabIndex = 16;
            this.btnRechercherMini.Text = "Rechercher";
            this.btnRechercherMini.UseVisualStyleBackColor = true;
            this.btnRechercherMini.Click += new System.EventHandler(this.btnRechercherMini_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnRechercherMini);
            this.groupBox1.Controls.Add(this.tbNumClientMini);
            this.groupBox1.Controls.Add(this.tbMtTicketsMini);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbRSClientMini);
            this.groupBox1.Controls.Add(this.tbMtContratMini);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbCAClientMini);
            this.groupBox1.Controls.Add(this.tbDureeMini);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbNAFClientMini);
            this.groupBox1.Controls.Add(this.tbDateContratMini);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(164, 76);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(421, 356);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rechercher un contrat avec la plus petite durée :";
            // 
            // frmDureeMiniContrat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 554);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmDureeMiniContrat";
            this.Text = "Contrats - Plus petite durée de contrats";
            this.Load += new System.EventHandler(this.frmDureeMiniContrat_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNumClientMini;
        private System.Windows.Forms.TextBox tbRSClientMini;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNAFClientMini;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbCAClientMini;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbMtTicketsMini;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbMtContratMini;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbDureeMini;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbDateContratMini;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnRechercherMini;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}