﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmTechnicienTauxHoraire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnValider = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbTauxMax = new System.Windows.Forms.TextBox();
            this.tbTauxMin = new System.Windows.Forms.TextBox();
            this.lVTechnicien = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(579, 328);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(75, 23);
            this.btnValider.TabIndex = 11;
            this.btnValider.Text = "Valider";
            this.btnValider.UseVisualStyleBackColor = true;
            this.btnValider.Click += new System.EventHandler(this.btnValider_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(506, 277);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Taux Horaire aximum";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(510, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Taux Horaire Minimum";
            // 
            // tbTauxMax
            // 
            this.tbTauxMax.Location = new System.Drawing.Point(618, 274);
            this.tbTauxMax.Name = "tbTauxMax";
            this.tbTauxMax.Size = new System.Drawing.Size(100, 20);
            this.tbTauxMax.TabIndex = 8;
            // 
            // tbTauxMin
            // 
            this.tbTauxMin.Location = new System.Drawing.Point(628, 149);
            this.tbTauxMin.Name = "tbTauxMin";
            this.tbTauxMin.Size = new System.Drawing.Size(100, 20);
            this.tbTauxMin.TabIndex = 7;
            // 
            // lVTechnicien
            // 
            this.lVTechnicien.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader1,
            this.columnHeader3});
            this.lVTechnicien.HideSelection = false;
            this.lVTechnicien.Location = new System.Drawing.Point(39, 27);
            this.lVTechnicien.Name = "lVTechnicien";
            this.lVTechnicien.Size = new System.Drawing.Size(414, 324);
            this.lVTechnicien.TabIndex = 6;
            this.lVTechnicien.UseCompatibleStateImageBehavior = false;
            this.lVTechnicien.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "N° technicien";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nom";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Prénom";
            // 
            // frmTechnicienTauxHoraire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(775, 398);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbTauxMax);
            this.Controls.Add(this.tbTauxMin);
            this.Controls.Add(this.lVTechnicien);
            this.Name = "frmTechnicienTauxHoraire";
            this.Text = "frmTechnicienTauxHoraire";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbTauxMax;
        private System.Windows.Forms.TextBox tbTauxMin;
        private System.Windows.Forms.ListView lVTechnicien;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}