﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmCloturerTickets : Form
    {
        public frmCloturerTickets()
        {
            InitializeComponent();
        }

        private void frmCloturerTickets_Load(object sender, EventArgs e)
        {
            // Initialisation d'une valeur par défaut pour la ComboBox technicien et pour la date de cloture ainsi que désactivation du changement de valeur pour celle-ci
            cbTech.Items.Add("Technicien ?");
            cbTech.SelectedIndex = 0;
            dtpDateCloture.Value = DateTime.Now;
            cbTech.Enabled = false;

            if (tab.nbTickets == 0 || tab.nbTech == 0)
            {
                MessageBox.Show("Aucun ticket ou aucun technicien", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //parcours du tableau des centres d'appel
                for (int i = 0; i < tab.nbTickets; i++)
                {
                    if (tab.ticket[i].cloture == false)
                    {
                        //configuration d'une ligne de la liste
                        ListViewItem ligne = new ListViewItem();
                        //1ère colonne = n° du ticket
                        ligne.Text = tab.ticket[i].numero.ToString();
                        //2ème colonne = date d'ouverture du ticket au format court (JJ/MM/AAA)
                        ligne.SubItems.Add(tab.ticket[i].dateOuverture.ToShortDateString());
                        //3ème colonne = raison sociale du client
                        // --> on récupère le n° du client
                        //     sa raison sociale est dans le tableau client
                        //     à l'indice n° du client -1 
                        int iClient = tab.ticket[i].numClient - 1;
                        ligne.SubItems.Add(tab.client[iClient].raisonSociale);
                        //4ème colonne = objet du ticket
                        ligne.SubItems.Add(tab.ticket[i].objet);

                        //ajout de la ligne dans la liste
                        lvTicketsNonCloture.Items.Add(ligne);
                    }
                }

                // Alimentation de la ComboBox technicien
                for (int j = 0; j < tab.nbTech; j++)
                {
                    cbTech.Items.Add(tab.tech[j].numero + " - " + tab.tech[j].nom + " " + tab.tech[j].prenom);
                }
            }
        }

        private void lvTicketsNonCloture_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Récupération du numéro du ticket grâce à la ListView
            int indexNumTicket = lvTicketsNonCloture.FocusedItem.Index;
            int NumTicket = Convert.ToInt32(lvTicketsNonCloture.Items[indexNumTicket].Text);

            // Vérification si un technicien est assigné au ticket séléctionné ou non
            int veriftech = 0;

            for (int k = 0; k < tab.nbTickets; k++)
            {
                veriftech = 0;
                if (tab.ticket[k].numero == NumTicket)
                {
                    veriftech = veriftech + tab.ticket[k].numTech;
                }
            }

            // Si il n'y a pas de tehcnicien de trouvé, alors la ComboBox se réactive pour pouvoir en sélécionner, sinon la ComboBox reste désactivé et prends la valeur du technicien trouvé 
            if (veriftech <= 0)
            {
                cbTech.Enabled = true;
                cbTech.SelectedIndex = 0;
            }
            else
            {
                cbTech.Enabled = false;

                int indexTech = 1;

                for (int l = 0; l < tab.nbTech; l++)
                {
                    if (tab.tech[l].numero == veriftech)
                    {
                        indexTech = indexTech + l;
                    }
                }

                cbTech.SelectedIndex = indexTech;
            }
        }

        private void btnCloturer_Click(object sender, EventArgs e)
        {
            if (dtpDateCloture.Value > tab.ticket[Convert.ToInt32(lvTicketsNonCloture.Items[lvTicketsNonCloture.FocusedItem.Index].Text)].dateOuverture && cbTech.Text != "Technicien ?" && numUDDureeTicket.Value != 0)
            {
                // Initialisation des variables venant récupérer les données nécessaires pour clôturer un ticket
                DateTime DateCloture = dtpDateCloture.Value;
                int Duree = Convert.ToInt32(numUDDureeTicket.Value);
                int Tech = 0;

                // Initialisation du montant total du ticket actuel
                float calculMtTicket = 0;

                // Si on peut séléctionner un téchnicient, une valeur prendra en compte celui-ci
                if (cbTech.Enabled == true)
                {
                    Tech = Tech + cbTech.SelectedIndex;
                }

                // Récupération du numéro de ticket pour la clôture
                int indexNumTicketCloture = lvTicketsNonCloture.FocusedItem.Index;
                int NumTicketCloture = Convert.ToInt32(lvTicketsNonCloture.Items[indexNumTicketCloture].Text);

                // Ajout des données à la class tab est clôture du ticket
                for (int m = 0; m < tab.nbTickets; m++)
                {
                    if (tab.ticket[m].numero == NumTicketCloture)
                    {
                        tab.ticket[m].cloture = true;
                        tab.ticket[m].dateCloture = DateCloture;
                        tab.ticket[m].nbHeures = Duree;

                        if (cbTech.Enabled == true)
                        {
                            tab.ticket[m].numTech = Tech;
                        }

                        // Calcul du montant du ticket par rapport au taux horaire du technicien et au nombre d'heures passé sur le ticket par celui-ci
                        calculMtTicket = calculMtTicket + (tab.ticket[m].nbHeures * tab.tech[tab.ticket[m].numTech - 1].tauxHoraire);

                        // Ajout du montant du ticket au montant total des tickets du client
                        tab.client[tab.ticket[m].numClient - 1].montantTickets = tab.client[tab.ticket[m].numClient - 1].montantTickets + calculMtTicket;
                    }
                }

                // Supression du ticket clôturé de la ListView des non-clôturés
                lvTicketsNonCloture.SelectedItems.Clear();
                lvTicketsNonCloture.Items.RemoveAt(indexNumTicketCloture);
            }
            else
            {
                MessageBox.Show("le technicien (valeur par défaut : 'Tehcnicien ?'), la date de cloture (ne peut pas être inférieure à la date d'ouverture) ou le nombre d'heures (ne peut pas être égal à 0) sont incorrectes. Veuillez les re-saisir !","Erreur données saisies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
