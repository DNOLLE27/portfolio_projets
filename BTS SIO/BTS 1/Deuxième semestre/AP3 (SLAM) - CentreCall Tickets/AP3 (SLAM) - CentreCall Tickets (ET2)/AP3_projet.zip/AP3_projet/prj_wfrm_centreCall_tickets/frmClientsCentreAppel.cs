﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmClientsCentreAppel : Form
    {
        public frmClientsCentreAppel()
        {
            InitializeComponent();
        }

        private void frmClientsCentreAppel_Load(object sender, EventArgs e)
        {
            // Ajout d'un item par défaut dans la ComboBox et séléction de la valeur par défaut
            cbCentreAppel.Items.Add("Ville ?");
            cbCentreAppel.SelectedIndex = 0;
            
            // Vérification présence de client et de centre d'appel, sinon allimentation de la ComboBox
            if (tab.nbClients == 0 || tab.nbCentresAppel == 0)
            {
                MessageBox.Show("Aucun client ou aucun centre d'appel", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Allimentation de la ComboBox avec toutes les villes des centres d'appels
                for (int i = 0; i < tab.nbCentresAppel; i++)
                {
                    cbCentreAppel.Items.Add(tab.centreAppel[i].ville);
                }
            }
        }

        private void btnRecherche_Click(object sender, EventArgs e)
        {
            // Récupération de la ville séléctionné dans la ComboBox
            string CentreAppelSel = cbCentreAppel.SelectedItem.ToString();

            // Nétoyage de la ListView pour éviter l'accumulation d'items
            lvClientsCentreAppel.Items.Clear();

            // Test de la saisie de la ville, sinon lancement de la recherche
            if (CentreAppelSel == "Ville ?")
            {
                MessageBox.Show("Aucune ville n'est séléctionnée, veuillez la saisir !", "Erreur saisie ville", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                for (int j = 0; j < tab.nbClients; j++)
                {
                    // Verification de la ville
                    int posCentre = tab.client[j].centreAppel - 1;
                    if (tab.centreAppel[posCentre].ville == CentreAppelSel)
                    {
                        // Déclaration nouvelle ligne pour la ListView
                        ListViewItem ligne = new ListViewItem();
                        
                        // ajout numéro client à la première colonne de la ligne et la raison social à la deuxième collonne de la ligne
                        ligne.Text = tab.client[j].numero.ToString();
                        ligne.SubItems.Add(tab.client[j].raisonSociale);

                        // Ajout de la ligne à la ListView
                        lvClientsCentreAppel.Items.Add(ligne);
                    }
                }
            }
        }
    }
}
