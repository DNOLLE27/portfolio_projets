﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmNbTicketsCentreAppel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvNbTicketCentreAppel = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lvNbTicketCentreAppel
            // 
            this.lvNbTicketCentreAppel.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvNbTicketCentreAppel.FullRowSelect = true;
            this.lvNbTicketCentreAppel.HideSelection = false;
            this.lvNbTicketCentreAppel.Location = new System.Drawing.Point(12, 12);
            this.lvNbTicketCentreAppel.Name = "lvNbTicketCentreAppel";
            this.lvNbTicketCentreAppel.Size = new System.Drawing.Size(776, 426);
            this.lvNbTicketCentreAppel.TabIndex = 0;
            this.lvNbTicketCentreAppel.UseCompatibleStateImageBehavior = false;
            this.lvNbTicketCentreAppel.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "N° centre d\'appel";
            this.columnHeader1.Width = 104;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Ville centre d\'appel";
            this.columnHeader2.Width = 112;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Nombre de tickets";
            this.columnHeader3.Width = 104;
            // 
            // frmNbTicketsCentreAppel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lvNbTicketCentreAppel);
            this.Name = "frmNbTicketsCentreAppel";
            this.Text = "Statistiques - Nombre de tickets par centre d\'appel";
            this.Load += new System.EventHandler(this.frmNbTicketsCentreAppel_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvNbTicketCentreAppel;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}