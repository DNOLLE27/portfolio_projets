﻿
namespace prj_wfrm_centreCall_tickets
{
    partial class frmCloturerTickets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvTicketsNonCloture = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label1 = new System.Windows.Forms.Label();
            this.cbTech = new System.Windows.Forms.ComboBox();
            this.dtpDateCloture = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.numUDDureeTicket = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCloturer = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.numUDDureeTicket)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvTicketsNonCloture
            // 
            this.lvTicketsNonCloture.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvTicketsNonCloture.FullRowSelect = true;
            this.lvTicketsNonCloture.HideSelection = false;
            this.lvTicketsNonCloture.Location = new System.Drawing.Point(11, 11);
            this.lvTicketsNonCloture.Margin = new System.Windows.Forms.Padding(2);
            this.lvTicketsNonCloture.Name = "lvTicketsNonCloture";
            this.lvTicketsNonCloture.Size = new System.Drawing.Size(778, 361);
            this.lvTicketsNonCloture.TabIndex = 3;
            this.lvTicketsNonCloture.UseCompatibleStateImageBehavior = false;
            this.lvTicketsNonCloture.View = System.Windows.Forms.View.Details;
            this.lvTicketsNonCloture.SelectedIndexChanged += new System.EventHandler(this.lvTicketsNonCloture_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "N°";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Date ticket";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Client";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Objet";
            this.columnHeader4.Width = 200;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Technicien :";
            // 
            // cbTech
            // 
            this.cbTech.FormattingEnabled = true;
            this.cbTech.Location = new System.Drawing.Point(18, 40);
            this.cbTech.Name = "cbTech";
            this.cbTech.Size = new System.Drawing.Size(121, 21);
            this.cbTech.TabIndex = 5;
            // 
            // dtpDateCloture
            // 
            this.dtpDateCloture.Location = new System.Drawing.Point(195, 41);
            this.dtpDateCloture.Name = "dtpDateCloture";
            this.dtpDateCloture.Size = new System.Drawing.Size(200, 20);
            this.dtpDateCloture.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Date de clôture :";
            // 
            // numUDDureeTicket
            // 
            this.numUDDureeTicket.Location = new System.Drawing.Point(459, 40);
            this.numUDDureeTicket.Name = "numUDDureeTicket";
            this.numUDDureeTicket.Size = new System.Drawing.Size(120, 20);
            this.numUDDureeTicket.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(456, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(456, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Durée du ticket (en heure) :";
            // 
            // btnCloturer
            // 
            this.btnCloturer.Location = new System.Drawing.Point(639, 20);
            this.btnCloturer.Name = "btnCloturer";
            this.btnCloturer.Size = new System.Drawing.Size(118, 40);
            this.btnCloturer.TabIndex = 11;
            this.btnCloturer.Text = "Clôturer";
            this.btnCloturer.UseVisualStyleBackColor = true;
            this.btnCloturer.Click += new System.EventHandler(this.btnCloturer_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbTech);
            this.groupBox1.Controls.Add(this.btnCloturer);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.dtpDateCloture);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.numUDDureeTicket);
            this.groupBox1.Location = new System.Drawing.Point(12, 377);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(777, 79);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Clôturer un ticket :";
            // 
            // frmCloturerTickets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 460);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lvTicketsNonCloture);
            this.Name = "frmCloturerTickets";
            this.Text = "Ticket - Clôturer des tickets";
            this.Load += new System.EventHandler(this.frmCloturerTickets_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUDDureeTicket)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvTicketsNonCloture;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbTech;
        private System.Windows.Forms.DateTimePicker dtpDateCloture;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numUDDureeTicket;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCloturer;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}