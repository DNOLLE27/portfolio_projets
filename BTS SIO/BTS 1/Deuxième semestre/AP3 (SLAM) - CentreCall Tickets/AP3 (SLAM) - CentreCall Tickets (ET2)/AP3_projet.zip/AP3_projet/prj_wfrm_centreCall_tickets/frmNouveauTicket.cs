﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prj_wfrm_centreCall_tickets
{
    public partial class frmNouveauTicket : Form
    {
        public frmNouveauTicket()
        {
            InitializeComponent();
        }

        private void btnAjout_Click(object sender, EventArgs e)
        {
            // Déclaration des variables pour récupérer les données saisie dans cette Form
            int Numero = Convert.ToInt32(numUDNumero.Value);
            DateTime DateDebut = dtpDateDebut.Value;
            string Objet = tbObjet.Text;
            int Client = cbClient.SelectedIndex;
            int Technicien = cbTechnicien.SelectedIndex;

            // Déclaration variable pour vérifier si le numéro du ticket saisie est déjà existant
            int cpt = 0;
            int numTrouve = 0;

            // Vérification des données pouvant être manquantes, sinon message erreur
            if (Objet != "" && Client != 0 && Technicien != 0)
            {
                // Vérification si le numéro du ticket existe déjà
                while (numTrouve == 0 && cpt < tab.nbTickets)
                {
                    if (tab.ticket[cpt].numero == Numero)
                    {
                        numTrouve = numTrouve + 1;
                    }
                    else
                    {
                        cpt++;
                    }
                }

                // Si le numéro du ticket n'existe pas, ajout des données dans la classe tab, sinon message erreur
                if (numTrouve == 0)
                {
                    tab.ticket[tab.nbTickets].numero = Numero;
                    tab.ticket[tab.nbTickets].dateOuverture = DateDebut;
                    tab.ticket[tab.nbTickets].objet = Objet;
                    tab.ticket[tab.nbTickets].numClient = Client;
                    tab.ticket[tab.nbTickets].numTech = Technicien;

                    // Forcer le nouveau ticket à être par défaut ouvert et nom cloturé
                    tab.ticket[tab.nbTickets].cloture = false;

                    // Modification du nombre de tickets dans la base tab
                    tab.nbTickets = tab.nbTickets + 1;

                    // forcer le nouveau numéro du ticket à prendre en compte la nouvelle valeur du nombre de tickets dans la base tab
                    numUDNumero.Value = tab.nbTickets + 1;
                }
                else
                {
                    MessageBox.Show("Désolé, le numéro du ticket que vous avez saisie est déjà existant. Veuillez en re-saisir un autre !", "Erreur saisi numéro ticket", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Désolé, il manque des données obligatoires qui ne sont pas saisi. Veuillez les saisir !", "Erreur données manquantes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void frmNouveauTicket_Load(object sender, EventArgs e)
        {
            // Initialisation du numéro du ticket et de la date ayant comme valeur par défaut : le nombre de ticket total contenu dans la classe tab + 1 et la date du jour 
            numUDNumero.Value = tab.nbTickets + 1;
            dtpDateDebut.Value = DateTime.Now;

            // Initialisation d'une valeur par défaut pour la ComboBox client
            cbClient.Items.Add("Client ?");
            cbClient.SelectedIndex = 0;

            // Initialisation d'une valeur par défaut pour la ComboBox technicien
            cbTechnicien.Items.Add("Technicien ?");
            cbTechnicien.SelectedIndex = 0;

            if (tab.nbClients == 0 || tab.nbTech == 0)
            {
                MessageBox.Show("Aucun client ou aucun technicien", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Alimentation de la ComboBox client
                for (int i = 0; i < tab.nbClients; i++)
                {
                    cbClient.Items.Add(tab.client[i].numero + " - " + tab.client[i].raisonSociale);
                }

                // Alimentation de la ComboBox technicien
                for (int j = 0; j < tab.nbTech; j++)
                {
                    cbTechnicien.Items.Add(tab.tech[j].numero + " - " + tab.tech[j].nom + " " + tab.tech[j].prenom);
                }
            }
        }
    }
}
