﻿namespace prj_wfrm_centreCall_tickets
{
    partial class frmMenu
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuFichier = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFichierOuvrir = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFichierEnregistrer = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFichierQuitter = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCentreAppel = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCentreAppelAfficher = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCentreAppelAfficherTous = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTechnicien = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTechnicienAfficher = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTechnicienAfficherTous = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClient = new System.Windows.Forms.ToolStripMenuItem();
            this.afficherToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClientAfficherTous = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClientsCentreAppel = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTicket = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTicketAfficher = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTicketAfficherTous = new System.Windows.Forms.ToolStripMenuItem();
            this.nouveauTicketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clôturerDesTicketsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCodeNaf = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCodeNafAfficher = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCodeNafAfficherTous = new System.Windows.Forms.ToolStripMenuItem();
            this.statistiquesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.afficherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nombreDeTicketsParCentreDappelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duréeMiniContratToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFichier,
            this.mnuCentreAppel,
            this.mnuTechnicien,
            this.mnuClient,
            this.mnuTicket,
            this.mnuCodeNaf,
            this.statistiquesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(1043, 38);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuFichier
            // 
            this.mnuFichier.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFichierOuvrir,
            this.mnuFichierEnregistrer,
            this.mnuFichierQuitter});
            this.mnuFichier.Image = ((System.Drawing.Image)(resources.GetObject("mnuFichier.Image")));
            this.mnuFichier.Name = "mnuFichier";
            this.mnuFichier.Size = new System.Drawing.Size(104, 36);
            this.mnuFichier.Text = "&Fichiers";
            // 
            // mnuFichierOuvrir
            // 
            this.mnuFichierOuvrir.Name = "mnuFichierOuvrir";
            this.mnuFichierOuvrir.Size = new System.Drawing.Size(163, 26);
            this.mnuFichierOuvrir.Text = "&Ouvrir";
            this.mnuFichierOuvrir.Click += new System.EventHandler(this.mnuFichierOuvrir_Click);
            // 
            // mnuFichierEnregistrer
            // 
            this.mnuFichierEnregistrer.Name = "mnuFichierEnregistrer";
            this.mnuFichierEnregistrer.Size = new System.Drawing.Size(163, 26);
            this.mnuFichierEnregistrer.Text = "&Enregistrer";
            this.mnuFichierEnregistrer.Click += new System.EventHandler(this.mnuFichierEnregistrer_Click);
            // 
            // mnuFichierQuitter
            // 
            this.mnuFichierQuitter.Name = "mnuFichierQuitter";
            this.mnuFichierQuitter.Size = new System.Drawing.Size(163, 26);
            this.mnuFichierQuitter.Text = "&Quitter";
            this.mnuFichierQuitter.Click += new System.EventHandler(this.mnuFichierQuitter_Click);
            // 
            // mnuCentreAppel
            // 
            this.mnuCentreAppel.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCentreAppelAfficher});
            this.mnuCentreAppel.Image = ((System.Drawing.Image)(resources.GetObject("mnuCentreAppel.Image")));
            this.mnuCentreAppel.Name = "mnuCentreAppel";
            this.mnuCentreAppel.Size = new System.Drawing.Size(146, 36);
            this.mnuCentreAppel.Text = "Centres &appel";
            // 
            // mnuCentreAppelAfficher
            // 
            this.mnuCentreAppelAfficher.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCentreAppelAfficherTous});
            this.mnuCentreAppelAfficher.Name = "mnuCentreAppelAfficher";
            this.mnuCentreAppelAfficher.Size = new System.Drawing.Size(144, 26);
            this.mnuCentreAppelAfficher.Text = "Afficher";
            // 
            // mnuCentreAppelAfficherTous
            // 
            this.mnuCentreAppelAfficherTous.Name = "mnuCentreAppelAfficherTous";
            this.mnuCentreAppelAfficherTous.Size = new System.Drawing.Size(122, 26);
            this.mnuCentreAppelAfficherTous.Text = "Tous";
            this.mnuCentreAppelAfficherTous.Click += new System.EventHandler(this.mnuCentreAppelAfficherTous_Click);
            // 
            // mnuTechnicien
            // 
            this.mnuTechnicien.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTechnicienAfficher});
            this.mnuTechnicien.Image = ((System.Drawing.Image)(resources.GetObject("mnuTechnicien.Image")));
            this.mnuTechnicien.Name = "mnuTechnicien";
            this.mnuTechnicien.Size = new System.Drawing.Size(130, 36);
            this.mnuTechnicien.Text = "Tec&hniciens";
            // 
            // mnuTechnicienAfficher
            // 
            this.mnuTechnicienAfficher.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTechnicienAfficherTous});
            this.mnuTechnicienAfficher.Name = "mnuTechnicienAfficher";
            this.mnuTechnicienAfficher.Size = new System.Drawing.Size(144, 26);
            this.mnuTechnicienAfficher.Text = "Afficher";
            // 
            // mnuTechnicienAfficherTous
            // 
            this.mnuTechnicienAfficherTous.Name = "mnuTechnicienAfficherTous";
            this.mnuTechnicienAfficherTous.Size = new System.Drawing.Size(122, 26);
            this.mnuTechnicienAfficherTous.Text = "Tous";
            this.mnuTechnicienAfficherTous.Click += new System.EventHandler(this.mnuTechnicienAfficherTous_Click);
            // 
            // mnuClient
            // 
            this.mnuClient.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.afficherToolStripMenuItem2});
            this.mnuClient.Image = ((System.Drawing.Image)(resources.GetObject("mnuClient.Image")));
            this.mnuClient.Name = "mnuClient";
            this.mnuClient.Size = new System.Drawing.Size(99, 36);
            this.mnuClient.Text = "&Clients";
            // 
            // afficherToolStripMenuItem2
            // 
            this.afficherToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClientAfficherTous,
            this.mnuClientsCentreAppel});
            this.afficherToolStripMenuItem2.Name = "afficherToolStripMenuItem2";
            this.afficherToolStripMenuItem2.Size = new System.Drawing.Size(144, 26);
            this.afficherToolStripMenuItem2.Text = "Afficher";
            // 
            // mnuClientAfficherTous
            // 
            this.mnuClientAfficherTous.Name = "mnuClientAfficherTous";
            this.mnuClientAfficherTous.Size = new System.Drawing.Size(261, 26);
            this.mnuClientAfficherTous.Text = "Tous";
            this.mnuClientAfficherTous.Click += new System.EventHandler(this.mnuClientAfficherTous_Click);
            // 
            // mnuClientsCentreAppel
            // 
            this.mnuClientsCentreAppel.Name = "mnuClientsCentreAppel";
            this.mnuClientsCentreAppel.Size = new System.Drawing.Size(261, 26);
            this.mnuClientsCentreAppel.Text = "Clients par centre d\'appel";
            this.mnuClientsCentreAppel.Click += new System.EventHandler(this.mnuClientsCentreAppel_Click);
            // 
            // mnuTicket
            // 
            this.mnuTicket.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTicketAfficher,
            this.nouveauTicketToolStripMenuItem,
            this.clôturerDesTicketsToolStripMenuItem});
            this.mnuTicket.Image = ((System.Drawing.Image)(resources.GetObject("mnuTicket.Image")));
            this.mnuTicket.Name = "mnuTicket";
            this.mnuTicket.Size = new System.Drawing.Size(100, 36);
            this.mnuTicket.Text = "&Tickets";
            // 
            // mnuTicketAfficher
            // 
            this.mnuTicketAfficher.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTicketAfficherTous});
            this.mnuTicketAfficher.Name = "mnuTicketAfficher";
            this.mnuTicketAfficher.Size = new System.Drawing.Size(224, 26);
            this.mnuTicketAfficher.Text = "Afficher";
            // 
            // mnuTicketAfficherTous
            // 
            this.mnuTicketAfficherTous.Name = "mnuTicketAfficherTous";
            this.mnuTicketAfficherTous.Size = new System.Drawing.Size(122, 26);
            this.mnuTicketAfficherTous.Text = "Tous";
            this.mnuTicketAfficherTous.Click += new System.EventHandler(this.mnuTicketAfficherTous_Click);
            // 
            // nouveauTicketToolStripMenuItem
            // 
            this.nouveauTicketToolStripMenuItem.Name = "nouveauTicketToolStripMenuItem";
            this.nouveauTicketToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.nouveauTicketToolStripMenuItem.Text = "Nouveau ticket";
            this.nouveauTicketToolStripMenuItem.Click += new System.EventHandler(this.nouveauTicketToolStripMenuItem_Click);
            // 
            // clôturerDesTicketsToolStripMenuItem
            // 
            this.clôturerDesTicketsToolStripMenuItem.Name = "clôturerDesTicketsToolStripMenuItem";
            this.clôturerDesTicketsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.clôturerDesTicketsToolStripMenuItem.Text = "Clôturer des Tickets";
            this.clôturerDesTicketsToolStripMenuItem.Click += new System.EventHandler(this.clôturerDesTicketsToolStripMenuItem_Click);
            // 
            // mnuCodeNaf
            // 
            this.mnuCodeNaf.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCodeNafAfficher});
            this.mnuCodeNaf.Image = ((System.Drawing.Image)(resources.GetObject("mnuCodeNaf.Image")));
            this.mnuCodeNaf.Name = "mnuCodeNaf";
            this.mnuCodeNaf.Size = new System.Drawing.Size(128, 36);
            this.mnuCodeNaf.Text = "Codes NAF";
            // 
            // mnuCodeNafAfficher
            // 
            this.mnuCodeNafAfficher.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCodeNafAfficherTous});
            this.mnuCodeNafAfficher.Name = "mnuCodeNafAfficher";
            this.mnuCodeNafAfficher.Size = new System.Drawing.Size(144, 26);
            this.mnuCodeNafAfficher.Text = "Afficher";
            // 
            // mnuCodeNafAfficherTous
            // 
            this.mnuCodeNafAfficherTous.Name = "mnuCodeNafAfficherTous";
            this.mnuCodeNafAfficherTous.Size = new System.Drawing.Size(122, 26);
            this.mnuCodeNafAfficherTous.Text = "Tous";
            this.mnuCodeNafAfficherTous.Click += new System.EventHandler(this.mnuCodeNafAfficherTous_Click);
            // 
            // statistiquesToolStripMenuItem
            // 
            this.statistiquesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.afficherToolStripMenuItem});
            this.statistiquesToolStripMenuItem.Name = "statistiquesToolStripMenuItem";
            this.statistiquesToolStripMenuItem.Size = new System.Drawing.Size(99, 36);
            this.statistiquesToolStripMenuItem.Text = "Statistiques";
            // 
            // afficherToolStripMenuItem
            // 
            this.afficherToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nombreDeTicketsParCentreDappelToolStripMenuItem,
            this.duréeMiniContratToolStripMenuItem});
            this.afficherToolStripMenuItem.Name = "afficherToolStripMenuItem";
            this.afficherToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.afficherToolStripMenuItem.Text = "Afficher";
            // 
            // nombreDeTicketsParCentreDappelToolStripMenuItem
            // 
            this.nombreDeTicketsParCentreDappelToolStripMenuItem.Name = "nombreDeTicketsParCentreDappelToolStripMenuItem";
            this.nombreDeTicketsParCentreDappelToolStripMenuItem.Size = new System.Drawing.Size(339, 26);
            this.nombreDeTicketsParCentreDappelToolStripMenuItem.Text = "Nombre de tickets par centre d\'appel";
            this.nombreDeTicketsParCentreDappelToolStripMenuItem.Click += new System.EventHandler(this.nombreDeTicketsParCentreDappelToolStripMenuItem_Click);
            // 
            // duréeMiniContratToolStripMenuItem
            // 
            this.duréeMiniContratToolStripMenuItem.Name = "duréeMiniContratToolStripMenuItem";
            this.duréeMiniContratToolStripMenuItem.Size = new System.Drawing.Size(339, 26);
            this.duréeMiniContratToolStripMenuItem.Text = "Durée Mini Contrat";
            this.duréeMiniContratToolStripMenuItem.Click += new System.EventHandler(this.duréeMiniContratToolStripMenuItem_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 564);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmMenu";
            this.Text = "Gestion des tickets chez CentreCall";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMenu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuFichier;
        private System.Windows.Forms.ToolStripMenuItem mnuFichierOuvrir;
        private System.Windows.Forms.ToolStripMenuItem mnuFichierEnregistrer;
        private System.Windows.Forms.ToolStripMenuItem mnuFichierQuitter;
        private System.Windows.Forms.ToolStripMenuItem mnuCentreAppel;
        private System.Windows.Forms.ToolStripMenuItem mnuCentreAppelAfficher;
        private System.Windows.Forms.ToolStripMenuItem mnuCentreAppelAfficherTous;
        private System.Windows.Forms.ToolStripMenuItem mnuTechnicien;
        private System.Windows.Forms.ToolStripMenuItem mnuTechnicienAfficher;
        private System.Windows.Forms.ToolStripMenuItem mnuTechnicienAfficherTous;
        private System.Windows.Forms.ToolStripMenuItem mnuClient;
        private System.Windows.Forms.ToolStripMenuItem afficherToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem mnuClientAfficherTous;
        private System.Windows.Forms.ToolStripMenuItem mnuTicket;
        private System.Windows.Forms.ToolStripMenuItem mnuTicketAfficher;
        private System.Windows.Forms.ToolStripMenuItem mnuTicketAfficherTous;
        private System.Windows.Forms.ToolStripMenuItem mnuCodeNaf;
        private System.Windows.Forms.ToolStripMenuItem mnuCodeNafAfficher;
        private System.Windows.Forms.ToolStripMenuItem mnuCodeNafAfficherTous;
        private System.Windows.Forms.ToolStripMenuItem mnuClientsCentreAppel;
        private System.Windows.Forms.ToolStripMenuItem nouveauTicketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statistiquesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem afficherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nombreDeTicketsParCentreDappelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clôturerDesTicketsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem duréeMiniContratToolStripMenuItem;
    }
}

