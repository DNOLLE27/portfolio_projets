﻿
namespace digicod_cryptage
{
    partial class FormCryptage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btndeconnection = new System.Windows.Forms.Button();
            this.lVDonnees = new System.Windows.Forms.ListView();
            this.cHPorte = new System.Windows.Forms.ColumnHeader();
            this.cHDateDebut = new System.Windows.Forms.ColumnHeader();
            this.cHDateFin = new System.Windows.Forms.ColumnHeader();
            this.cHCodeCrypte = new System.Windows.Forms.ColumnHeader();
            this.cHEtatMdP = new System.Windows.Forms.ColumnHeader();
            this.cBAjoutPortes = new System.Windows.Forms.ComboBox();
            this.tBAjoutMdP = new System.Windows.Forms.TextBox();
            this.btnajoutvalider = new System.Windows.Forms.Button();
            this.btnquitter = new System.Windows.Forms.Button();
            this.tBLog = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btndeconnection
            // 
            this.btndeconnection.Location = new System.Drawing.Point(745, 413);
            this.btndeconnection.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btndeconnection.Name = "btndeconnection";
            this.btndeconnection.Size = new System.Drawing.Size(147, 31);
            this.btndeconnection.TabIndex = 0;
            this.btndeconnection.Text = "Se déconnecter";
            this.btndeconnection.UseVisualStyleBackColor = true;
            this.btndeconnection.Click += new System.EventHandler(this.btndeconnection_Click);
            // 
            // lVDonnees
            // 
            this.lVDonnees.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.cHPorte,
            this.cHDateDebut,
            this.cHDateFin,
            this.cHCodeCrypte,
            this.cHEtatMdP});
            this.lVDonnees.HideSelection = false;
            this.lVDonnees.Location = new System.Drawing.Point(11, 16);
            this.lVDonnees.Name = "lVDonnees";
            this.lVDonnees.Size = new System.Drawing.Size(879, 389);
            this.lVDonnees.TabIndex = 1;
            this.lVDonnees.UseCompatibleStateImageBehavior = false;
            this.lVDonnees.View = System.Windows.Forms.View.Details;
            // 
            // cHPorte
            // 
            this.cHPorte.Text = "Porte";
            // 
            // cHDateDebut
            // 
            this.cHDateDebut.Text = "Date Début";
            this.cHDateDebut.Width = 100;
            // 
            // cHDateFin
            // 
            this.cHDateFin.Text = "Date Fin";
            this.cHDateFin.Width = 100;
            // 
            // cHCodeCrypte
            // 
            this.cHCodeCrypte.Text = "Code Crypté";
            this.cHCodeCrypte.Width = 100;
            // 
            // cHEtatMdP
            // 
            this.cHEtatMdP.Text = "État";
            this.cHEtatMdP.Width = 100;
            // 
            // cBAjoutPortes
            // 
            this.cBAjoutPortes.FormattingEnabled = true;
            this.cBAjoutPortes.Items.AddRange(new object[] {
            "E",
            "I",
            "T"});
            this.cBAjoutPortes.Location = new System.Drawing.Point(6, 26);
            this.cBAjoutPortes.Name = "cBAjoutPortes";
            this.cBAjoutPortes.Size = new System.Drawing.Size(46, 28);
            this.cBAjoutPortes.TabIndex = 2;
            this.cBAjoutPortes.Text = "T";
            this.cBAjoutPortes.SelectedIndexChanged += new System.EventHandler(this.cBAjoutPortes_SelectedIndexChanged);
            // 
            // tBAjoutMdP
            // 
            this.tBAjoutMdP.Location = new System.Drawing.Point(57, 26);
            this.tBAjoutMdP.Name = "tBAjoutMdP";
            this.tBAjoutMdP.Size = new System.Drawing.Size(125, 27);
            this.tBAjoutMdP.TabIndex = 3;
            this.tBAjoutMdP.TextChanged += new System.EventHandler(this.tBAjoutMdP_TextChanged);
            // 
            // btnajoutvalider
            // 
            this.btnajoutvalider.Location = new System.Drawing.Point(189, 26);
            this.btnajoutvalider.Name = "btnajoutvalider";
            this.btnajoutvalider.Size = new System.Drawing.Size(94, 29);
            this.btnajoutvalider.TabIndex = 4;
            this.btnajoutvalider.Text = "Ajouter";
            this.btnajoutvalider.UseVisualStyleBackColor = true;
            this.btnajoutvalider.Click += new System.EventHandler(this.btnajoutvalider_Click);
            // 
            // btnquitter
            // 
            this.btnquitter.Location = new System.Drawing.Point(745, 453);
            this.btnquitter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnquitter.Name = "btnquitter";
            this.btnquitter.Size = new System.Drawing.Size(147, 31);
            this.btnquitter.TabIndex = 5;
            this.btnquitter.Text = "Quitter";
            this.btnquitter.UseVisualStyleBackColor = true;
            this.btnquitter.Click += new System.EventHandler(this.btnquitter_Click);
            // 
            // tBLog
            // 
            this.tBLog.Location = new System.Drawing.Point(299, 415);
            this.tBLog.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tBLog.Multiline = true;
            this.tBLog.Name = "tBLog";
            this.tBLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tBLog.Size = new System.Drawing.Size(438, 68);
            this.tBLog.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cBAjoutPortes);
            this.groupBox1.Controls.Add(this.tBAjoutMdP);
            this.groupBox1.Controls.Add(this.btnajoutvalider);
            this.groupBox1.Location = new System.Drawing.Point(2, 411);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(291, 73);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ajouter des données :";
            // 
            // FormCryptage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 492);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tBLog);
            this.Controls.Add(this.btnquitter);
            this.Controls.Add(this.lVDonnees);
            this.Controls.Add(this.btndeconnection);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "FormCryptage";
            this.Text = "FormCryptage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormCryptage_FormClosed);
            this.Load += new System.EventHandler(this.FormCryptage_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btndeconnection;
        private System.Windows.Forms.ListView lVDonnees;
        private System.Windows.Forms.ComboBox cBAjoutPortes;
        private System.Windows.Forms.TextBox tBAjoutMdP;
        private System.Windows.Forms.ColumnHeader cHPorte;
        private System.Windows.Forms.ColumnHeader cHDateDebut;
        private System.Windows.Forms.ColumnHeader cHDateFin;
        private System.Windows.Forms.ColumnHeader cHCodeCrypte;
        private System.Windows.Forms.Button btnajoutvalider;
        private System.Windows.Forms.Button btnquitter;
        private System.Windows.Forms.ColumnHeader cHEtatMdP;
        private System.Windows.Forms.TextBox tBLog;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}