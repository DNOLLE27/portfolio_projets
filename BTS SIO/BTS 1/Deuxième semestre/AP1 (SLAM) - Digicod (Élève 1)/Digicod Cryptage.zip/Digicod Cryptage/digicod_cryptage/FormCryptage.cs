﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace digicod_cryptage
{
    public partial class FormCryptage : Form
    {
        public FormCryptage()
        {
            InitializeComponent();
        }

        private string Cryptage(string porte, string mdp)
        {
            string[] alphabet = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
            string mdptiret = "";
            string[] mdptableau;
            string mdpcryptage = "";
            int positionalphabetcrypte;
            
            for (int i = 0; i < mdp.Length; i++)
            {
                if (i == (mdp.Length - 1))
                {
                    mdptiret = mdptiret + mdp.Substring(i,1);
                }
                else
                {
                    mdptiret = mdptiret + mdp.Substring(i, 1) + "-";
                }
            }

            mdptableau = mdptiret.Split('-');

            if (porte == "I")
            {
                for (int k = 0; k < mdptableau.Length; k++)
                {
                    for (int l = 0; l < alphabet.Length; l++)
                    {
                        if (mdptableau[k] == alphabet[l])
                        {
                            positionalphabetcrypte = ((33 * l) + 1) % 26;
                            mdpcryptage = mdpcryptage + alphabet[positionalphabetcrypte];
                        }
                    }
                }
            }
            else if (porte == "E")
            {
                for (int k = 0; k < mdptableau.Length; k++)
                {
                    for (int l = 0; l < alphabet.Length; l++)
                    {
                        if (mdptableau[k] == alphabet[l])
                        {
                            positionalphabetcrypte = (l + 10) % 26;
                            mdpcryptage = mdpcryptage + alphabet[positionalphabetcrypte];
                        }
                    }
                }
            }
            else if (porte == "T")
            {
                mdpcryptage = mdp;
            }

            return mdpcryptage;
        }

        private void AjoutDonnees(string porte, DateTime datededebut, DateTime datedefin, string mdp)
        {
            StreamWriter digicod_secure_fichier = new StreamWriter("digicod_secure.csv", true);
            string ajoutdonneescsv;
            DateTime dateactuelberif = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy"));
            int i = Donnees.nbListe;

            Donnees.tabListe[i].porte = porte;
            Donnees.tabListe[i].datedebut = datededebut.ToString("dd/MM/yyyy");
            Donnees.tabListe[i].datefin = datedefin.ToString("dd/MM/yyyy");
            Donnees.tabListe[i].codecrypte = mdp;

            if (dateactuelberif < datededebut)
            { 
                Donnees.tabListe[i].etatmdp = "Bientôt Valide";
            }
            else
            {
                Donnees.tabListe[i].etatmdp = "Valide";
            }

            Donnees.nbListe = i + 1;

            ListViewItem laLigne = new ListViewItem();

            laLigne.Text = Donnees.tabListe[i].porte;
            laLigne.SubItems.Add(Donnees.tabListe[i].datedebut);
            laLigne.SubItems.Add(Donnees.tabListe[i].datefin);
            laLigne.SubItems.Add(Donnees.tabListe[i].codecrypte);
            laLigne.SubItems.Add(Donnees.tabListe[i].etatmdp);

            lVDonnees.Items.Add(laLigne);

            if (Donnees.tabListe[i].etatmdp == "Bientôt Valide")
            { 
                for (int comptcolonnes = 0; comptcolonnes < lVDonnees.Columns.Count; comptcolonnes++)
                {
                    lVDonnees.Items[i].UseItemStyleForSubItems = false;
                    lVDonnees.Items[i].SubItems[comptcolonnes].ForeColor = Color.Blue;
                }
            }
            else
            {
                for (int comptcolonnes = 0; comptcolonnes < lVDonnees.Columns.Count; comptcolonnes++)
                {
                    lVDonnees.Items[i].UseItemStyleForSubItems = false;
                    lVDonnees.Items[i].SubItems[comptcolonnes].ForeColor = Color.Green;
                }
            }

            ajoutdonneescsv = porte + ";" + Convert.ToString(datededebut).Substring(0,10) + ";" + Convert.ToString(datedefin).Substring(0, 10) + ";" + mdp;
            digicod_secure_fichier.WriteLine(ajoutdonneescsv);
            digicod_secure_fichier.Flush();
            digicod_secure_fichier.Close();
        }


        private void btndeconnection_Click(object sender, EventArgs e)
        {
            Form laFormLogin = new FormLogin();
            laFormLogin.Show();
            this.Hide();
        }

        private void FormCryptage_Load(object sender, EventArgs e)
        {
            btnajoutvalider.Enabled = false;
            tBLog.ReadOnly = true;
            tBAjoutMdP.CharacterCasing = CharacterCasing.Upper;

            int comptPI = 0;

            StreamReader digicod_secure_fichier = new StreamReader("digicod_secure.csv", Encoding.Default);

            string ligneFichier;
            ligneFichier = digicod_secure_fichier.ReadLine();

            int i = 0;
            while ((ligneFichier = digicod_secure_fichier.ReadLine()) != null)
            {
                string[] lesColonnes;
                lesColonnes = ligneFichier.Split(';');

                Donnees.tabListe[i].porte = lesColonnes[0];
                Donnees.tabListe[i].datedebut = lesColonnes[1];
                Donnees.tabListe[i].datefin = lesColonnes[2];
                Donnees.tabListe[i].codecrypte = lesColonnes[3];
                i++;
            }
            Donnees.nbListe = i;
            digicod_secure_fichier.Close();

            for (int k = 0; k < Donnees.nbListe; k++)
            {
                DateTime datedebut;
                DateTime datefin;
                DateTime dateactuel;
                int joursrestants;

                datedebut = DateTime.Parse(Donnees.tabListe[k].datedebut);
                datefin = DateTime.Parse(Donnees.tabListe[k].datefin);
                dateactuel = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy"));
                joursrestants = Convert.ToInt32((datefin.Date - dateactuel.Date).Days);

                if (dateactuel.Date > datefin.Date)
                {
                    Donnees.tabListe[k].etatmdp = "Invalide";
                }
                else if (datedebut.Date < dateactuel.Date && dateactuel.Date < datefin.Date && joursrestants > 3)
                {
                    Donnees.tabListe[k].etatmdp = "Valide";
                }
                else if (joursrestants <= 3)
                {
                    Donnees.tabListe[k].etatmdp = "Presque Invalide";
                    comptPI++;
                }
                else if (dateactuel.Date < datedebut.Date)
                {
                    Donnees.tabListe[k].etatmdp = "Bientôt Valide";
                }
            }

            for (int j = 0; j < Donnees.nbListe; j++)
            {
                ListViewItem laLigne = new ListViewItem();

                laLigne.Text = Donnees.tabListe[j].porte;
                laLigne.SubItems.Add(Donnees.tabListe[j].datedebut);
                laLigne.SubItems.Add(Donnees.tabListe[j].datefin); 
                laLigne.SubItems.Add(Donnees.tabListe[j].codecrypte);
                laLigne.SubItems.Add(Donnees.tabListe[j].etatmdp);

                lVDonnees.Items.Add(laLigne);
            }

            for (int comptcolonnes = 0; comptcolonnes < lVDonnees.Columns.Count; comptcolonnes++)
            {
                for (int comptlignes = 0; comptlignes < Donnees.nbListe; comptlignes++)
                {
                    string etatmdp = lVDonnees.Items[comptlignes].SubItems[4].Text;
                    if (etatmdp == "Invalide")
                    {
                        lVDonnees.Items[comptlignes].UseItemStyleForSubItems = false;
                        lVDonnees.Items[comptlignes].SubItems[comptcolonnes].ForeColor = Color.Red;
                    }
                    else if (etatmdp == "Presque Invalide")
                    {
                        lVDonnees.Items[comptlignes].UseItemStyleForSubItems = false;
                        lVDonnees.Items[comptlignes].SubItems[comptcolonnes].ForeColor = Color.Orange;
                    }
                    else if (etatmdp == "Valide")
                    {
                        lVDonnees.Items[comptlignes].UseItemStyleForSubItems = false;
                        lVDonnees.Items[comptlignes].SubItems[comptcolonnes].ForeColor = Color.Green;
                    }
                    else if (etatmdp == "Bientôt Valide")
                    {
                        lVDonnees.Items[comptlignes].UseItemStyleForSubItems = false;
                        lVDonnees.Items[comptlignes].SubItems[comptcolonnes].ForeColor = Color.Blue;
                    }
                }
            }

            if (comptPI != 0)
            {
                string titre = "Attention !";
                string message = "Il y a " + comptPI + " Mot(s) de passe(s) qui va/vont bientôt expirer (État = \"Presque Invalide\"). Veuillez penser à en générer un/des nouveau(x) !";
                MessageBoxButtons bouton = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                DialogResult afficher;

                afficher = MessageBox.Show(message, titre, bouton, icon);
            }
        }

        private void FormCryptage_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnquitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnajoutvalider_Click(object sender, EventArgs e)
        {
            tBLog.Text = "";
            string log = "";

            log = log + "Verification en cours...\r\n";
            tBLog.Text = log;

            string ajoutmdp = tBAjoutMdP.Text;
            string ajoutporte = Convert.ToString(cBAjoutPortes.SelectedItem);
            string ajoutmdpcode;

            string[] chiffre = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            int comptchiffre = 0;
            int comptportevalide = 0;
            int comptporteinvalide = 0;
            int comptportepresqueinvalide = 0;
            int PositionPI = 0;

            DateTime datedebutajout;
            DateTime datefinajout;
            DateTime dateactuelajout;

            for (int i = 0; i < chiffre.Length; i++)
            {
                for (int k = 0; k < ajoutmdp.Length; k++)
                {
                    if (k < ajoutmdp.Length)
                    {
                        if (ajoutmdp.Substring(k, 1) == chiffre[i])
                        {
                            comptchiffre++;
                        }
                    }
                    else
                    {
                        if (ajoutmdp.Substring(k) == chiffre[i])
                        {
                            comptchiffre++;
                        }
                    }
                }
            }

            if (comptchiffre != 0)
            {
                log = log + "ERROR1: Le mot de passe contient des chiffres !\r\n";
                tBLog.Text = log;
            }
            else
            {
                if (ajoutmdp.Length < 6)
                {
                    log = log + "ERROR2-1: Le mot de passe saisie contient moins de 6 caractères !\r\n";
                    tBLog.Text = log;
                }
                else if (ajoutmdp.Length > 6)
                {
                    log = log + "ERROR2-2: Le mot de passe saisie contient plus de 6 caractères !\r\n";
                    tBLog.Text = log;
                }
                else
                {
                    for (int j = 0; j < Donnees.nbListe; j++)
                    {
                        if (lVDonnees.Items[j].SubItems[0].Text == ajoutporte)
                        {
                            if (lVDonnees.Items[j].SubItems[4].Text == "Valide" || lVDonnees.Items[j].SubItems[4].Text == "Bientôt Valide")
                            {
                                comptportevalide++;
                            }
                            else if (lVDonnees.Items[j].SubItems[4].Text == "Presque Invalide")
                            {
                                comptportepresqueinvalide++;
                            }
                            else if (lVDonnees.Items[j].SubItems[4].Text == "Invalide")
                            {
                                comptporteinvalide++;
                            }
                        }
                    }

                    if (comptportevalide != 0)
                    {
                        log = log + "ERROR3: un mot de passe est ''Valide'' ou ''Bientôt Valide'' pour la porte actuellement sélectionée, vous ne pouvez avoir qu'un mot de passe active par porte !\r\n";
                        tBLog.Text = log;
                    }
                    
                    if (comptportepresqueinvalide != 0 && comptportevalide == 0)
                    {
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        for (int h = 0; h < Donnees.nbListe; h++)
                        {
                            if (lVDonnees.Items[h].SubItems[0].Text == ajoutporte && lVDonnees.Items[h].SubItems[4].Text == "Presque Invalide")
                            {
                                PositionPI = PositionPI + h;
                            }
                        }

                        log = log + "Calcul date de début en cours...\r\n";
                        tBLog.Text = log;
                        datedebutajout = Convert.ToDateTime(lVDonnees.Items[PositionPI].SubItems[2].Text);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Calcul date de fin en cours...\r\n";
                        tBLog.Text = log;
                        datefinajout = datedebutajout.AddDays(31);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Génération du mot de passe en cours...\r\n";
                        tBLog.Text = log;
                        ajoutmdpcode = Cryptage(ajoutporte, ajoutmdp);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Ajout des données créer en cours...\r\n";
                        tBLog.Text = log;
                        AjoutDonnees(ajoutporte, datedebutajout, datefinajout, ajoutmdpcode);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;
                    }
                    else if (comptporteinvalide != 0 && comptportevalide == 0 && comptportepresqueinvalide == 0)
                    {
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        dateactuelajout = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy"));

                        log = log + "Calcul date de début en cours...\r\n";
                        tBLog.Text = log;
                        datedebutajout = dateactuelajout.AddDays(-1);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Calcul date de fin en cours...\r\n";
                        tBLog.Text = log;
                        datefinajout = datedebutajout.AddDays(31);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Génération du mot de passe en cours...\r\n";
                        tBLog.Text = log;
                        ajoutmdpcode = Cryptage(ajoutporte, ajoutmdp);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Ajout des données créer en cours...\r\n";
                        tBLog.Text = log;
                        AjoutDonnees(ajoutporte, datedebutajout, datefinajout, ajoutmdpcode);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;
                    }
                    else if (comptportevalide == 0 && comptportepresqueinvalide == 0 && comptporteinvalide == 0)
                    {
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        dateactuelajout = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy"));

                        log = log + "Calcul date de début en cours...\r\n";
                        tBLog.Text = log;
                        datedebutajout = dateactuelajout.AddDays(-1);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Calcul date de fin en cours...\r\n";
                        tBLog.Text = log;
                        datefinajout = datedebutajout.AddDays(31);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Génération du mot de passe en cours...\r\n";
                        tBLog.Text = log;
                        ajoutmdpcode = Cryptage(ajoutporte, ajoutmdp);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;

                        log = log + "Ajout des données créer en cours...\r\n";
                        tBLog.Text = log;
                        AjoutDonnees(ajoutporte,datedebutajout,datefinajout,ajoutmdpcode);
                        log = log + "Terminé !\r\n";
                        tBLog.Text = log;
                    }
                }
            }
        }

        private void tBAjoutMdP_TextChanged(object sender, EventArgs e)
        {
            if (tBAjoutMdP.Text != "" && Convert.ToString(cBAjoutPortes.SelectedItem) != "")
            {
                btnajoutvalider.Enabled = true;
            }
            else
            {
                btnajoutvalider.Enabled = false;
            }
        }

        private void cBAjoutPortes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tBAjoutMdP.Text != "" && Convert.ToString(cBAjoutPortes.SelectedItem) != "")
            {
                btnajoutvalider.Enabled = true;
            }
            else
            {
                btnajoutvalider.Enabled = false;
            }
        }
    }
}
