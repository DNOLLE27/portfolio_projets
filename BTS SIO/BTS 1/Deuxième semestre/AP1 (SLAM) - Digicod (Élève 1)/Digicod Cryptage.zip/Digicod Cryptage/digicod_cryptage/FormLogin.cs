﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace digicod_cryptage
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            btnconnexion.Enabled = false;
            lblmatricule.Visible = false;
            lblmdp.Visible = false;
            tBMdP.PasswordChar = '*';
            tBMdP.MaxLength = 6;
        }

        private string[] Extract(StreamReader fichiercsv, int nbcol)
        {
            string ligneFichier;
            ligneFichier = fichiercsv.ReadLine();

            string[] colonnefinal = new string[0];

            int i = 0;
            while ((ligneFichier = fichiercsv.ReadLine()) != null)
            {
                string[] lesColonnes;
                lesColonnes = ligneFichier.Split(';');

                Array.Resize(ref colonnefinal, colonnefinal.Length + 1);
                colonnefinal[i] = lesColonnes[nbcol];

                i++;
            }
            fichiercsv.Close();

            return colonnefinal;
        }

        private void numUDMatricule_ValueChanged(object sender, EventArgs e)
        {
            if (numUDMatricule.Value != 1000 && tBMdP.Text != "")
            {
                btnconnexion.Enabled = true;
            }
            else
            {
                btnconnexion.Enabled = false;
                lblmdp.Visible = false;
                lblmatricule.Visible = false;
            }
        }

        private void tBMdP_TextChanged(object sender, EventArgs e)
        {
            if (numUDMatricule.Value != 1000 && tBMdP.Text != "")
            {
                btnconnexion.Enabled = true;
            }
            else
            {
                btnconnexion.Enabled = false;
                lblmdp.Visible = false;
                lblmatricule.Visible = false;
            }
        }

        private void btnquitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnnouveau_Click(object sender, EventArgs e)
        {
            tBMdP.Text = "";
            numUDMatricule.Value = 1000;
        }

        private void btnconnexion_Click(object sender, EventArgs e)
        {
            StreamReader digicod_perso_matricule = new StreamReader("digicod_perso.csv", Encoding.Default);
            StreamReader digicod_perso_autorisation = new StreamReader("digicod_perso.csv", Encoding.Default);
            StreamReader digicod_secure_porte = new StreamReader("digicod_secure.csv", Encoding.Default);
            StreamReader digicod_secure_datedebut = new StreamReader("digicod_secure.csv", Encoding.Default);
            StreamReader digicod_secure_datefin = new StreamReader("digicod_secure.csv", Encoding.Default);
            StreamReader digicod_secure_codecrypte = new StreamReader("digicod_secure.csv", Encoding.Default);

            string[] matriculeFichier;
            string[] autorisationFichier;
            string[] porteFichier;
            string[] datedebutFichier;
            string[] datefinFichier;
            string[] codecrypteFichier;

            int matricule;
            DateTime datedebut;
            DateTime datefin;
            DateTime dateactuel;
            string MdP;

            matriculeFichier = Extract(digicod_perso_matricule, 0);
            autorisationFichier = Extract(digicod_perso_autorisation, 3);
            porteFichier = Extract(digicod_secure_porte, 0);
            datedebutFichier = Extract(digicod_secure_datedebut, 1);
            datefinFichier = Extract(digicod_secure_datefin, 2);
            codecrypteFichier = Extract(digicod_secure_codecrypte, 3);

            matricule = Convert.ToInt32(numUDMatricule.Value);
            MdP = tBMdP.Text;

            int comptMdP = 0;
            bool ouvrirform = false;

            for (int i = 0; i < matriculeFichier.Length; i++)
            {
                if (Convert.ToInt32(matriculeFichier[i]) == matricule)
                {
                    lblmatricule.Visible = false;
                    if (autorisationFichier[i] == "T")
                    {
                        for (int k = 0; k < porteFichier.Length; k++)
                        {
                            if (porteFichier[k] == "T")
                            {
                                datedebut = DateTime.Parse(datedebutFichier[k]);
                                datefin = DateTime.Parse(datefinFichier[k]);
                                dateactuel = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy"));

                                if (datedebut.Date < dateactuel.Date && dateactuel.Date < datefin.Date)
                                {
                                    if (MdP == codecrypteFichier[k])
                                    {
                                        comptMdP++;
                                    }
                                }

                                if (comptMdP != 1)
                                {
                                    lblmdp.Visible = true;
                                }
                                else
                                {
                                    lblmdp.Visible = false;
                                    ouvrirform = true;

                                }
                            }
                        }
                    }
                    else if (i + 1 == matriculeFichier.Length)
                    {
                        lblmatricule.Visible = true;
                    }
                }
                else if (i + 1 == matriculeFichier.Length)
                {
                    lblmatricule.Visible = true;
                }
            }

            if (ouvrirform == true)
            {
                Form laFormCryptage = new FormCryptage();
                laFormCryptage.Show();
                this.Hide();
            }
        }

        private void FormLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
