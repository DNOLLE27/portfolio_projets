﻿
namespace digicod_cryptage
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnquitter = new System.Windows.Forms.Button();
            this.btnnouveau = new System.Windows.Forms.Button();
            this.numUDMatricule = new System.Windows.Forms.NumericUpDown();
            this.lblmdp = new System.Windows.Forms.Label();
            this.lblmatricule = new System.Windows.Forms.Label();
            this.btnconnexion = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tBMdP = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numUDMatricule)).BeginInit();
            this.SuspendLayout();
            // 
            // btnquitter
            // 
            this.btnquitter.Location = new System.Drawing.Point(426, 258);
            this.btnquitter.Name = "btnquitter";
            this.btnquitter.Size = new System.Drawing.Size(93, 30);
            this.btnquitter.TabIndex = 27;
            this.btnquitter.Text = "Quitter";
            this.btnquitter.UseVisualStyleBackColor = true;
            this.btnquitter.Click += new System.EventHandler(this.btnquitter_Click);
            // 
            // btnnouveau
            // 
            this.btnnouveau.Location = new System.Drawing.Point(12, 258);
            this.btnnouveau.Name = "btnnouveau";
            this.btnnouveau.Size = new System.Drawing.Size(93, 30);
            this.btnnouveau.TabIndex = 26;
            this.btnnouveau.Text = "Nouveau";
            this.btnnouveau.UseVisualStyleBackColor = true;
            this.btnnouveau.Click += new System.EventHandler(this.btnnouveau_Click);
            // 
            // numUDMatricule
            // 
            this.numUDMatricule.Location = new System.Drawing.Point(163, 36);
            this.numUDMatricule.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.numUDMatricule.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numUDMatricule.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numUDMatricule.Name = "numUDMatricule";
            this.numUDMatricule.Size = new System.Drawing.Size(187, 23);
            this.numUDMatricule.TabIndex = 25;
            this.numUDMatricule.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numUDMatricule.ValueChanged += new System.EventHandler(this.numUDMatricule_ValueChanged);
            // 
            // lblmdp
            // 
            this.lblmdp.AutoSize = true;
            this.lblmdp.ForeColor = System.Drawing.Color.Red;
            this.lblmdp.Location = new System.Drawing.Point(163, 120);
            this.lblmdp.Name = "lblmdp";
            this.lblmdp.Size = new System.Drawing.Size(170, 15);
            this.lblmdp.TabIndex = 24;
            this.lblmdp.Text = "* Ce mot de passe est incorrect";
            // 
            // lblmatricule
            // 
            this.lblmatricule.AutoSize = true;
            this.lblmatricule.ForeColor = System.Drawing.Color.Red;
            this.lblmatricule.Location = new System.Drawing.Point(163, 59);
            this.lblmatricule.Name = "lblmatricule";
            this.lblmatricule.Size = new System.Drawing.Size(150, 15);
            this.lblmatricule.TabIndex = 23;
            this.lblmatricule.Text = "* Ce matricule est incorrect";
            // 
            // btnconnexion
            // 
            this.btnconnexion.Location = new System.Drawing.Point(204, 144);
            this.btnconnexion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnconnexion.Name = "btnconnexion";
            this.btnconnexion.Size = new System.Drawing.Size(101, 43);
            this.btnconnexion.TabIndex = 22;
            this.btnconnexion.Text = "Connexion";
            this.btnconnexion.UseVisualStyleBackColor = true;
            this.btnconnexion.Click += new System.EventHandler(this.btnconnexion_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(163, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 15);
            this.label2.TabIndex = 21;
            this.label2.Text = "Mot de passe :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(164, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 20;
            this.label1.Text = "Matricule :";
            // 
            // tBMdP
            // 
            this.tBMdP.Location = new System.Drawing.Point(163, 97);
            this.tBMdP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tBMdP.Name = "tBMdP";
            this.tBMdP.Size = new System.Drawing.Size(188, 23);
            this.tBMdP.TabIndex = 19;
            this.tBMdP.TextChanged += new System.EventHandler(this.tBMdP_TextChanged);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 307);
            this.Controls.Add(this.btnquitter);
            this.Controls.Add(this.btnnouveau);
            this.Controls.Add(this.numUDMatricule);
            this.Controls.Add(this.lblmdp);
            this.Controls.Add(this.lblmatricule);
            this.Controls.Add(this.btnconnexion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tBMdP);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormLogin";
            this.Text = "FormLogin";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormLogin_FormClosed);
            this.Load += new System.EventHandler(this.FormLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUDMatricule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnquitter;
        private System.Windows.Forms.Button btnnouveau;
        private System.Windows.Forms.NumericUpDown numUDMatricule;
        private System.Windows.Forms.Label lblmdp;
        private System.Windows.Forms.Label lblmatricule;
        private System.Windows.Forms.Button btnconnexion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBMdP;
    }
}