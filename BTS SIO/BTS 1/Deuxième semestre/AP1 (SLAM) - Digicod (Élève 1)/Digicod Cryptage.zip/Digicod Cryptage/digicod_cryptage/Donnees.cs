﻿using System;
using System.Collections.Generic;
using System.Text;

namespace digicod_cryptage
{
    class Donnees
    {
        public struct liste
        {
            public String porte;
            public String datedebut;
            public String datefin;
            public String codecrypte;
            public String etatmdp;
        }

        public static liste[] tabListe = new liste[100];
        public static int nbListe = 0;
    }
}
