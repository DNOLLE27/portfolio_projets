﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace prj_wfrm_digicod_liste_erreurs
{
    public partial class frmErreurListe : Form
    {
        public frmErreurListe()
        {
            InitializeComponent();
        }

        private void btFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmErreurListe_Load(object sender, EventArgs e)
        {
            //parcours du tableau des erreurs
            for(int i = 0 ; i< donnees.nbListe; i++)
            {
                //définition d'une nouvelle ligne de la liste
                ListViewItem laLigne = new ListViewItem();

                //définition des 4 colonnes
                laLigne.Text = donnees.tabListe[i].matricule;   //colonne 1
                laLigne.SubItems.Add(donnees.tabListe[i].date); //colonne 2
                laLigne.SubItems.Add(donnees.tabListe[i].heure); //colonne 3
                laLigne.SubItems.Add(donnees.tabListe[i].porte); //colonne 4

                //insertion de la ligne dans la liste
                lvErreurs.Items.Add(laLigne);
            }
        }

        private void lvErreurs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
