﻿namespace prj_wfrm_digicod_liste_erreurs
{
    partial class frmErreurListe
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvErreurs = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btFermer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvErreurs
            // 
            this.lvErreurs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvErreurs.Location = new System.Drawing.Point(79, 31);
            this.lvErreurs.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lvErreurs.Name = "lvErreurs";
            this.lvErreurs.Size = new System.Drawing.Size(469, 331);
            this.lvErreurs.TabIndex = 0;
            this.lvErreurs.UseCompatibleStateImageBehavior = false;
            this.lvErreurs.View = System.Windows.Forms.View.Details;
            this.lvErreurs.SelectedIndexChanged += new System.EventHandler(this.lvErreurs_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Matricule";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Date";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Heure";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Porte";
            // 
            // btFermer
            // 
            this.btFermer.Location = new System.Drawing.Point(251, 393);
            this.btFermer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btFermer.Name = "btFermer";
            this.btFermer.Size = new System.Drawing.Size(136, 46);
            this.btFermer.TabIndex = 1;
            this.btFermer.Text = "&Fermer";
            this.btFermer.UseVisualStyleBackColor = true;
            this.btFermer.Click += new System.EventHandler(this.btFermer_Click);
            // 
            // frmErreurListe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 506);
            this.Controls.Add(this.btFermer);
            this.Controls.Add(this.lvErreurs);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmErreurListe";
            this.Text = "DIGICOD - Liste des erreurs";
            this.Load += new System.EventHandler(this.frmErreurListe_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvErreurs;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btFermer;

    }
}

