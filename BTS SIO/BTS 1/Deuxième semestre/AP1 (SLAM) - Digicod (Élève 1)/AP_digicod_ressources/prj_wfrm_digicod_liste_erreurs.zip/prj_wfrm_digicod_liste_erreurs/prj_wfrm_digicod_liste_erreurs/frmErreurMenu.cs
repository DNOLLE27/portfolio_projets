﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prj_wfrm_digicod_liste_erreurs
{
    public partial class frmErreurMenu : Form
    {
        public frmErreurMenu()
        {
            InitializeComponent();
        }

        private void ouvrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ouvrirFichier.ShowDialog();
        }

        private void ouvrirFichier_FileOk(object sender, CancelEventArgs e)
        {
            //ouverture du fichier
            StreamReader monFichier = new StreamReader(ouvrirFichier.FileName);
            
            //lecture des données pour enregistrement dans le tableau structuré
            

            string ligneFichier;
            //lecture de la ligne de titre
            ligneFichier = monFichier.ReadLine();

            //lecture des autres lignes 
            int i = 0;
            while ((ligneFichier = monFichier.ReadLine()) != null)
            {
                //extraction des informations des 4 colonnes 
                //pour les placer dans le tableau structuré
                string[] lesColonnes;
                lesColonnes = ligneFichier.Split(';');

                donnees.tabListe[i].matricule = lesColonnes[0];
                donnees.tabListe[i].date = lesColonnes[1];
                donnees.tabListe[i].heure = lesColonnes[2];
                donnees.tabListe[i].porte = lesColonnes[3];
                i++;
            }
            //nombre de lignes dans le tableau
            donnees.nbListe = i;

            //fermeture du fichier
            monFichier.Close();
        }

        private void frmErreurMenu_Load(object sender, EventArgs e)
        {

        }

        private void afficherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmErreurListe maForm = new frmErreurListe();
            maForm.Show();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
