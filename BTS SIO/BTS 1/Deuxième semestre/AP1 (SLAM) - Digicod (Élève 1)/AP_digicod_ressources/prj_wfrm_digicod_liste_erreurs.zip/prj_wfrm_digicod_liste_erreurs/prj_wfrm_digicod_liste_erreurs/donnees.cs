﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace prj_wfrm_digicod_liste_erreurs
{
    class donnees
    {
        public struct liste
        {
            public String matricule;
            public String date;
            public String heure;
            public String porte;
        }

        public static liste[] tabListe = new liste[100];             
        public static int nbListe = 0;
    }
}
