
#include "maze.h"
using namespace maze;

Maze::Maze(const char ascii[16][16], startPoint point)
{
   // créer les noeuds en fonction du caractère

   // créer les liens entres voisins

    // point de départ
}

Maze::~Maze()
{
   // peut-être des choses à supprimer
}

bool Maze::checkConsistency()
{
   // tous les noeuds sont instanciés

   // point de départ valide
}

bool Maze::solve()
{
   return this->parse(this->starter);
}

void Maze::getAsciiFormat(char ascii[16][16])
{
}

bool Maze::parse(mazeNode::Node *node)
{
   // la récursivité peut-être intéressante pour le parcours d'un arbre de noeuds
}
