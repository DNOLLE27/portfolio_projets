
#include "node.h"
using namespace mazeNode;

Node::Node()
{
   // par défaut les voisins sont nulls et le type du noeud NodeType_Wall
}

Node::~Node()
{

}

eNodeType Node::getType()
{
   // retourne le type de noeud
}

void Node::setNeighbor(eNodeNeighbor position, Node* neighbor)
{
}

Node* Node::getNeighbor(eNodeNeighbor position)
{
}

bool Node::isNeighborFree(eNodeNeighbor position)
{
   // Est-ce que le voisin à la position donnée existe et peut-être visité ?
}

void Node::setVisited()
{
}

bool Node::isVisited()
{
}

bool Node::isFreeToVisit()
{
}

NodeWall::NodeWall() : Node()
{
   this->type = NodeType_Wall;
}

const char NodeWall::getString()
{
   return 'w';
}

NodeFree::NodeFree() : Node()
{
   this->type = NodeType_Free;
}

const char NodeFree::getString()
{
   if (this->visited)
      return '.';

   return ' ';
}

NodeCheese::NodeCheese() : Node()
{
   this->type = NodeType_Cheese;
}

const char NodeCheese::getString()
{
   if (this->visited)
      return 'X';

   return 'c';
}
